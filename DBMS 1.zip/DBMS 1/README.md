# PSR_DBMS
we shall discuss about main topics here :-)
